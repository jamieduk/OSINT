
#!/usr/bin/env python3
# (c) J~Net 2026
#
# Usage: python3 email2phonenumber.py
# Usage: python3 email2phonenumber.py -e user@example.com

import argparse
import re
import socket
import sys
from urllib.parse import urlsplit

GREEN="\033[92m"
YELLOW="\033[93m"
RED="\033[91m"
ENDC="\033[0m"

def check_email(email):
    """Validate email syntax and check whether its domain resolves."""

    email=email.strip()

    if not email:
        print(f"{RED}Error: No email address supplied.{ENDC}")
        return False

    pattern=r"^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)+$"

    if len(email)>254 or not re.fullmatch(pattern,email):
        print(f"{RED}Invalid email address format.{ENDC}")
        return False

    domain=email.rsplit("@",1)[1]

    print(f"{GREEN}Email format: valid{ENDC}")
    print(f"Checking domain: {domain}")

    try:
        socket.getaddrinfo(domain,None,type=socket.SOCK_STREAM)
        print(f"{GREEN}Domain DNS resolution: successful{ENDC}")
        print(f"{YELLOW}Mailbox existence: not verified{ENDC}")
        return True

    except socket.gaierror as error:
        print(f"{YELLOW}Domain DNS resolution failed: {error}{ENDC}")
        return False

    except OSError as error:
        print(f"{RED}Network error: {error}{ENDC}")
        return False

def main():
    parser=argparse.ArgumentParser(
        description="Validate an email address and check domain DNS."
    )

    parser.add_argument(
        "-e","--email",
        help="Email address to validate"
    )

    args=parser.parse_args()

    email=args.email

    if not email:
        try:
            email=input("Enter Email to lookup: ").strip()
        except (EOFError,KeyboardInterrupt):
            print("\nCancelled.")
            return 130

    print(f"\nChecking email: {email}\n")

    return 0 if check_email(email) else 1

if __name__=="__main__":
    sys.exit(main())

