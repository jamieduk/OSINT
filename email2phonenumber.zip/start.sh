#!/bin/bash
# (c) J~Net 2026
#
# Usage: ./start.sh
# Usage: ./start.sh user@example.com

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
EMAIL="$1"

if [[ -z "$EMAIL" ]]; then
    read -r -p "Enter Email to lookup: " EMAIL
fi

if [[ -z "$EMAIL" ]]; then
    echo "Error: No email address supplied."
    exit 1
fi

echo "Trying Email $EMAIL Lookup..."

cd "$SCRIPT_DIR" || exit 1

python3 email2phonenumber.py --email "$EMAIL"

