#!/bin/bash
# (c) J~Net 2026
#
# ./setup.sh
#
#

function venv() {
    #python3 -m venv venv
    python3.14 -m venv venv
    PYTHON_PATH=$(which python3.14)
    echo "alias python='$PYTHON_PATH'" >> venv/bin/activate
    source venv/bin/activate
    echo "Virtual Environment setup and ready!"
    echo ""
}

venv
pip3 install beautifulsoup4 requests

